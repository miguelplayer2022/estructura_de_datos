
package presentacion;


public class INGRESAR extends javax.swing.JFrame {

    /**
     * Creates new form INGRESAR
     */
    public INGRESAR() {
        initComponents();
        setLocationRelativeTo(null);
        configurarAcciones();
    }

   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jTextField2 = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setText("INGRESE SU NOMBRE");

        jLabel2.setText("INGRESE SU CEDULA ");

        jButton1.setText("INSERTAR");

        jButton2.setText("BUSCAR ");

        jButton3.setText("CONSULTAR");

        jButton4.setText("ELIMINAR");

        jButton5.setText("SALIR ");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(58, 58, 58)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel1)
                            .addComponent(jLabel2))
                        .addGap(41, 41, 41)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jTextField1)
                            .addComponent(jTextField2, javax.swing.GroupLayout.DEFAULT_SIZE, 165, Short.MAX_VALUE)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(31, 31, 31)
                        .addComponent(jButton1)
                        .addGap(28, 28, 28)
                        .addComponent(jButton2)
                        .addGap(18, 18, 18)
                        .addComponent(jButton3))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(76, 76, 76)
                        .addComponent(jButton4)
                        .addGap(56, 56, 56)
                        .addComponent(jButton5)))
                .addContainerGap(22, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(33, 33, 33)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(jTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(34, 34, 34)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton1)
                    .addComponent(jButton2)
                    .addComponent(jButton3))
                .addGap(27, 27, 27)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton4)
                    .addComponent(jButton5))
                .addContainerGap(98, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void configurarAcciones() {
        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        jButton1.addActionListener(e -> insertar());
        jButton2.addActionListener(e -> buscar());
        jButton3.addActionListener(e -> consultar());
        jButton4.addActionListener(e -> eliminar());
        jButton5.addActionListener(e -> dispose());
    }

    private java.sql.Connection conexion() throws java.sql.SQLException {
        return java.sql.DriverManager.getConnection(
            System.getProperty("mdi.db.url", "jdbc:mysql://localhost:3306/sistema_mdi?useUnicode=true&characterEncoding=UTF-8&useSSL=false"),
            System.getProperty("mdi.db.user", "root"),
            System.getProperty("mdi.db.password", ""));
    }

    private void error(Exception ex) {
        javax.swing.JOptionPane.showMessageDialog(this, "Error de base de datos: " + ex.getMessage(), "Error", javax.swing.JOptionPane.ERROR_MESSAGE);
    }

    private void insertar() {
        String nombre = jTextField1.getText().trim();
        String cedula = jTextField2.getText().trim();
        if (nombre.isEmpty() || cedula.isEmpty()) {
            javax.swing.JOptionPane.showMessageDialog(this, "Ingrese nombre y cédula."); return;
        }
        String sql = "INSERT INTO personas_ingresar (nombre, cedula) VALUES (?, ?)";
        try (java.sql.Connection c = conexion() ; java.sql.PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, nombre); ps.setString(2, cedula); ps.executeUpdate();
            javax.swing.JOptionPane.showMessageDialog(this, "Registro guardado correctamente.");
            jTextField1.setText(""); jTextField2.setText("");
        } catch (java.sql.SQLIntegrityConstraintViolationException ex) {
            javax.swing.JOptionPane.showMessageDialog(this, "La cédula ya está registrada.");
        } catch (java.sql.SQLException ex) { error(ex); }
    }

    private void buscar() {
        String cedula = jTextField2.getText().trim();
        if (cedula.isEmpty()) { javax.swing.JOptionPane.showMessageDialog(this, "Ingrese la cédula que desea buscar."); return; }
        try (java.sql.Connection c = conexion(); java.sql.PreparedStatement ps = c.prepareStatement("SELECT nombre, cedula FROM personas_ingresar WHERE cedula = ?")) {
            ps.setString(1, cedula);
            try (java.sql.ResultSet rs = ps.executeQuery()) {
                if (rs.next()) { jTextField1.setText(rs.getString("nombre")); jTextField2.setText(rs.getString("cedula")); }
                else { jTextField1.setText(""); javax.swing.JOptionPane.showMessageDialog(this, "No se encontró esa cédula."); }
            }
        } catch (java.sql.SQLException ex) { error(ex); }
    }

    private void consultar() {
        javax.swing.table.DefaultTableModel modelo = new javax.swing.table.DefaultTableModel(new String[]{"ID", "Nombre", "Cédula"}, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        try (java.sql.Connection c = conexion(); java.sql.PreparedStatement ps = c.prepareStatement("SELECT id, nombre, cedula FROM personas_ingresar ORDER BY id DESC"); java.sql.ResultSet rs = ps.executeQuery()) {
            while (rs.next()) modelo.addRow(new Object[]{rs.getInt("id"), rs.getString("nombre"), rs.getString("cedula")});
            javax.swing.JTable tabla = new javax.swing.JTable(modelo);
            javax.swing.JScrollPane scroll = new javax.swing.JScrollPane(tabla);
            scroll.setPreferredSize(new java.awt.Dimension(550, 300));
            javax.swing.JOptionPane.showMessageDialog(this, scroll, "Registros consultados: " + modelo.getRowCount(), javax.swing.JOptionPane.INFORMATION_MESSAGE);
        } catch (java.sql.SQLException ex) { error(ex); }
    }

    private void eliminar() {
        String cedula = jTextField2.getText().trim();
        if (cedula.isEmpty()) { javax.swing.JOptionPane.showMessageDialog(this, "Ingrese la cédula a eliminar."); return; }
        int confirmar = javax.swing.JOptionPane.showConfirmDialog(this, "¿Eliminar el registro con cédula " + cedula + "?", "Confirmar eliminación", javax.swing.JOptionPane.YES_NO_OPTION);
        if (confirmar != javax.swing.JOptionPane.YES_OPTION) return;
        try (java.sql.Connection c = conexion(); java.sql.PreparedStatement ps = c.prepareStatement("DELETE FROM personas_ingresar WHERE cedula = ?")) {
            ps.setString(1, cedula);
            int filas = ps.executeUpdate();
            javax.swing.JOptionPane.showMessageDialog(this, filas > 0 ? "Registro eliminado." : "No se encontró esa cédula.");
            if (filas > 0) { jTextField1.setText(""); jTextField2.setText(""); }
        } catch (java.sql.SQLException ex) { error(ex); }
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(INGRESAR.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(INGRESAR.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(INGRESAR.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(INGRESAR.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new INGRESAR().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField2;
    // End of variables declaration//GEN-END:variables
}
